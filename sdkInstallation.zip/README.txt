+======================================+
|AUTOMATE INSTALLATION FOR SDK IN LINUX|
+======================================+

1. Install deb/rpm installation files for UPOS 1.14.14 version from Toshiba's portal

2. Download the desire SDK version and move it to the UPOS directory

2. Download sdkInstallation.tar or sdkInstallation.zip file from \\10.89.159.16\IanMunozNunez

3. Decompress the file using "tar" or "unzip" commands

4. Run "sdkInstall" file using root permissions and with the following parameters
    1. DEB/RPM files directory (directory where DEB/RPM files for UPOS and SDK are located)
    2. The extension files that you want to install, options:
        - deb
        - rpm
    3. Examples:
        - sudo ./sdkInstall /home/${USER}/Desktop/DEB/ deb
        - sudo ./sdkInstall RPM/ rpm

+====================================+
|MANUAL INSTALLATION FOR SDK IN LINUX|
+====================================+

1. Install the following packages
    - openjdk-8-jdk
    - openssl

2. Download the UPOS deb/rpm files package from Toshiba's portal.

3. Go to installation files and install the files using the following order
    1. toshibaposs-gcc
    2. toshiba-javapos
    3. javax-usb
    4. javax-usb-ri
    5. javax-usb-ri-linux

4. Install the deb/rpm SDK file

5. Create secure certificates for WSS using keytool and openssl or download them from \\10.89.159.16\IanMunozNunez\keystore

6. Edit the file "/opt/tgcs/device-broker/conf/broker-http.properties" and add the correct path in
    - broker-http.wss.key
    - broker-http.wss.keyStore
    - broker-http.wss.trustStore

7. Add the following variable to "/opt/tgcs/device-broker/bin/start-broker.sh"
    - export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${TCX_SDK_HOME}/lib/so/:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/amd64/:"

